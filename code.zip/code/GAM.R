rm(list=ls())
library(mgcv) 
library(openxlsx)
library(visreg)
library(chngpt)
library(splines)
library(ggplot2)
library(rio)
library(jpeg)
library(export)
library(broom)
library(gam)
library(readxl)

file_names <- list.files('aa')
AIC_data <-matrix(nrow=76,ncol=4)

for (i in 1:76) {
  name <- file_names[i]
  graphics.off() 
  data <- read.xlsx(paste0("aa",name),sheet=1,na.strings="NaN",startRow=0,colNames = FALSE)
  
  
  data1 <- data.frame(data)
  colnames(data1) <- c('year','lat','lon','alt','tmp','pre','swf','vpd','ring')
  
  data_sort<-data1[order(data1$year),]
  
  gam_model1<-mgcv::gam(ring ~ s(vpd)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model2<-mgcv::gam(ring ~ s(vpd)+s(tmp)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model3<-mgcv::gam(ring ~ s(vpd)+s(pre)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model4<-mgcv::gam(ring ~ s(vpd)+s(swf)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model1<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  gam_model2<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          ti(vpd,tmp)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  gam_model3<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          ti(vpd,pre)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  gam_model4<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          ti(vpd,swf)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  sm1 <- summary(gam_model1)
  gam_terms1 <- data.frame(
    term    = rownames(sm1$s.table),
    EDF     = sm1$s.table[, "edf"],
    RefDF  = sm1$s.table[, "Ref.df"],
    F      = sm1$s.table[, "F"],
    p_value= sm1$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms1 <- gam_terms1[
    gam_terms1$term %in% c("s(vpd)","ti(vpd,tmp)"),
  ]
  
  model_terms1 <- data.frame(
    term    = vpd_terms1$term,
    EDF     = vpd_terms1$EDF,
    RefDF  = vpd_terms1$RefDF,
    F      = vpd_terms1$F,
    p_value= vpd_terms1$p_value,
    r2= sm1$r.sq
  )
  sm2 <- summary(gam_model2)
  gam_terms2 <- data.frame(
    term    = rownames(sm2$s.table),
    EDF     = sm2$s.table[, "edf"],
    RefDF  = sm2$s.table[, "Ref.df"],
    F      = sm2$s.table[, "F"],
    p_value= sm2$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms2 <- gam_terms2[
    gam_terms2$term %in% c("s(vpd)","ti(vpd,tmp)"),
  ]
  model_terms2 <- data.frame(
    term    = vpd_terms2$term,
    EDF     = vpd_terms2$EDF,
    RefDF  = vpd_terms2$RefDF,
    F      = vpd_terms2$F,
    p_value= vpd_terms2$p_value,
    r2= sm2$r.sq
  )
  sm3 <- summary(gam_model3)
  gam_terms3 <- data.frame(
    term    = rownames(sm3$s.table),
    EDF     = sm3$s.table[, "edf"],
    RefDF  = sm3$s.table[, "Ref.df"],
    F      = sm3$s.table[, "F"],
    p_value= sm3$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms3 <- gam_terms3[
    gam_terms3$term %in% c("s(vpd)","ti(vpd,pre)"),
  ]
  model_terms3 <- data.frame(
    term    = vpd_terms3$term,
    EDF     = vpd_terms3$EDF,
    RefDF  = vpd_terms3$RefDF,
    F      = vpd_terms3$F,
    p_value= vpd_terms3$p_value,
    r2= sm3$r.sq
  )
  sm4 <- summary(gam_model4)
  gam_terms4 <- data.frame(
    term    = rownames(sm4$s.table),
    EDF     = sm4$s.table[, "edf"],
    RefDF  = sm4$s.table[, "Ref.df"],
    F      = sm4$s.table[, "F"],
    p_value= sm4$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms4 <- gam_terms4[
    gam_terms4$term %in% c("s(vpd)","ti(vpd,swf)"),
  ]
  model_terms4 <- data.frame(
    term    = vpd_terms4$term,
    EDF     = vpd_terms4$EDF,
    RefDF  = vpd_terms4$RefDF,
    F      = vpd_terms4$F,
    p_value= vpd_terms4$p_value,
    r2= sm4$r.sq
  )
  
  
  ####
  pic1 <-  visreg(gam_model1,'vpd', cex.lab=1.5,cex.axis=1.5,scale = "response")
  plot_data1 <- data.frame(pic1$fit$vpd,pic1$fit$visregFit,pic1$fit$visregLwr,pic1$fit$visregUpr)
  
  pic11 <- ggplot(plot_data1, aes(x=pic1$fit$vpd, y=pic1$fit$visregFit))+
    geom_line(size=2,color='blue')+
    labs(x='VPD',y='Tree Growth', size=10)+
    theme(axis.text = element_text(size=30,color = "black"))+
    theme(axis.title  = element_text(size=30))+
    theme(axis.line = element_line(color = "black"))+
    geom_line(aes(x=pic1$fit$vpd, y=pic1$fit$visregLwr),alpha=0)+
    geom_line(aes(x=pic1$fit$vpd, y=pic1$fit$visregUpr),alpha=0)+
    geom_ribbon(aes(ymin=pic1$fit$visregLwr,ymax=pic1$fit$visregUpr),fill='gray',alpha=0.5)+
    theme(plot.margin = margin(0.1, 1, 0.1, 0.1, "cm"))
  name1 <- substr(name,1,5)
  ggsave(paste0("F:/VPD_Threshold/Revise_PNAS/Pic_Revise/model_only_vpd/",name1,'.jpg'),plot=pic11,width = 12, height = 10)
  write.csv(plot_data1, paste0("F:/VPD_Threshold/Revise_PNAS/Results/plot_data/model_only_vpd/",name1,'.csv'), row.names = FALSE)
  write.csv(model_terms1,paste0("F:/VPD_Threshold/Revise_PNAS/Results/model_terms_无交互/model1/",name1,'.csv'),row.names = FALSE)
  write.csv(concurvity_data,paste0("F:/VPD_Threshold/Revise_PNAS/Results/Concurvity/",name1,'.csv'),row.names = FALSE)
  #####
  pic2 <-  visreg(gam_model2,'vpd', cex.lab=1.5,cex.axis=1.5,scale = "response")
  plot_data2 <- data.frame(pic2$fit$vpd,pic2$fit$visregFit,pic2$fit$visregLwr,pic2$fit$visregUpr)
  
  pic22 <- ggplot(plot_data2, aes(x=pic2$fit$vpd, y=pic2$fit$visregFit))+
    geom_line(size=2,color='blue')+
    labs(x='VPD',y='Tree Growth', size=10)+
    theme(axis.text = element_text(size=30,color = "black"))+
    theme(axis.title  = element_text(size=30))+
    theme(axis.line = element_line(color = "black"))+
    geom_line(aes(x=pic2$fit$vpd, y=pic2$fit$visregLwr),alpha=0)+
    geom_line(aes(x=pic2$fit$vpd, y=pic2$fit$visregUpr),alpha=0)+
    geom_ribbon(aes(ymin=pic2$fit$visregLwr,ymax=pic2$fit$visregUpr),fill='gray',alpha=0.5)+
    theme(plot.margin = margin(0.1, 1, 0.1, 0.1, "cm"))
  name2 <- substr(name,1,5)
  ggsave(paste0("F:/VPD_Threshold/Revise_PNAS/Pic_Revise/model_vpd_tmp/",name2,'.jpg'),plot=pic22,width = 12, height = 10)
  write.csv(plot_data2, paste0("F:/VPD_Threshold/Revise_PNAS/Results/plot_data/model_vpd_tmp/",name2,'.csv'), row.names = FALSE)
  write.csv(model_terms2,paste0("F:/VPD_Threshold/Revise_PNAS/Results/model_terms_无交互//model2/",name2,'.csv'),row.names = FALSE)
  #####
  pic3 <-  visreg(gam_model3,'vpd', cex.lab=1.5,cex.axis=1.5,scale = "response")
  plot_data3 <- data.frame(pic3$fit$vpd,pic3$fit$visregFit,pic3$fit$visregLwr,pic3$fit$visregUpr)
  
  pic33 <- ggplot(plot_data3, aes(x=pic3$fit$vpd, y=pic3$fit$visregFit))+
    geom_line(size=2,color='blue')+
    labs(x='VPD',y='Tree Growth', size=10)+
    theme(axis.text = element_text(size=30,color = "black"))+
    theme(axis.title  = element_text(size=30))+
    theme(axis.line = element_line(color = "black"))+
    geom_line(aes(x=pic3$fit$vpd, y=pic3$fit$visregLwr),alpha=0)+
    geom_line(aes(x=pic3$fit$vpd, y=pic3$fit$visregUpr),alpha=0)+
    geom_ribbon(aes(ymin=pic3$fit$visregLwr,ymax=pic3$fit$visregUpr),fill='gray',alpha=0.5)+
    theme(plot.margin = margin(0.1, 1, 0.1, 0.1, "cm"))
  name3 <- substr(name,1,5)
  ggsave(paste0("F:/VPD_Threshold/Revise_PNAS/Pic_Revise/model_vpd_pre/",name3,'.jpg'),plot=pic33,width = 12, height = 10)
  write.csv(plot_data3, paste0("F:/VPD_Threshold/Revise_PNAS/Results/plot_data/model_vpd_pre/",name3,'.csv'), row.names = FALSE)
  write.csv(model_terms3,paste0("F:/VPD_Threshold/Revise_PNAS/Results/model_terms_无交互//model3/",name3,'.csv'),row.names = FALSE)
  #####
  pic4 <-  visreg(gam_model4,'vpd', cex.lab=1.5,cex.axis=1.5,scale = "response")
  plot_data4 <- data.frame(pic4$fit$vpd,pic4$fit$visregFit,pic4$fit$visregLwr,pic4$fit$visregUpr)
  
  pic44 <- ggplot(plot_data4, aes(x=pic4$fit$vpd, y=pic4$fit$visregFit))+
    geom_line(size=2,color='blue')+
    labs(x='VPD',y='Tree Growth', size=10)+
    theme(axis.text = element_text(size=30,color = "black"))+
    theme(axis.title  = element_text(size=30))+
    theme(axis.line = element_line(color = "black"))+
    geom_line(aes(x=pic4$fit$vpd, y=pic4$fit$visregLwr),alpha=0)+
    geom_line(aes(x=pic4$fit$vpd, y=pic4$fit$visregUpr),alpha=0)+
    geom_ribbon(aes(ymin=pic4$fit$visregLwr,ymax=pic4$fit$visregUpr),fill='gray',alpha=0.5)+
    theme(plot.margin = margin(0.1, 1, 0.1, 0.1, "cm"))
  name4 <- substr(name,1,5)
  ggsave(paste0("F:/VPD_Threshold/Revise_PNAS/Pic_Revise/model_vpd_swf/",name4,'.jpg'),plot=pic44,width = 12, height = 10)
  write.csv(plot_data4, paste0("F:/VPD_Threshold/Revise_PNAS/Results/plot_data/model_vpd_swf/",name4,'.csv'), row.names = FALSE)
  write.csv(model_terms4,paste0("F:/VPD_Threshold/Revise_PNAS/Results/model_terms_无交互//model4/",name4,'.csv'),row.names = FALSE)
  
  print(i)
}
#mgcv::concurvity(gam_model1, full = TRUE)


