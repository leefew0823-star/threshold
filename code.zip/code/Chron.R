# example
citation("dplR")
library(dplR)
# 1. Africa-
mainDir<-"aa/"
mainDir1<-"aa/"
setwd(mainDir)
filenames<-dir(mainDir)
filepath<-sapply(filenames,function(x){
  paste(mainDir,x,sep='')
})

for (i in 1:30){
  data<-read.rwl(filepath[i])
  yrs<-rownames(data)
  corename<-colnames(data)
  # detrend zimb001 with spline
  data.rwi<-detrend(data,method='Spline',nyrs=30,f=0.5)
  # build a chronology
  data.crn<-chron(data.rwi,prefix='HUR',biweight = TRUE,prewhiten=TRUE)
  yrsnum<-yrs>=1901
  yrs2 <- yrs[yrsnum]
  nyrs<-length(yrs2)
  if (nyrs>=25){
    sitecode<-filenames[i]
    stringlength<-nchar(sitecode)
    sitestring<-substring(sitecode,1,stringlength-4)
    write.table(data.crn, paste(mainDir1, "africa/", sitestring, ".csv", sep=""), sep=",", col.names=TRUE, row.names= TRUE);
  }
}


