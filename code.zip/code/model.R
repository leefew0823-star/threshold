## Example of GAM
rm(list=ls())
library(mgcv) 
library(openxlsx)
library(visreg)
library(chngpt)
library(splines)
library(ggplot2)
library(rio)
library(jpeg)
library(export)
library(broom)
library(gam)
library(readxl)

file_names <- list.files('aa')
AIC_data <-matrix(nrow=76,ncol=4)

for (i in 1:76) {
  name <- file_names[i]
  graphics.off() 
  data <- read.xlsx(paste0("aa",name),sheet=1,na.strings="NaN",startRow=0,colNames = FALSE)
  
  
  data1 <- data.frame(data)
  colnames(data1) <- c('year','lat','lon','alt','tmp','pre','swf','vpd','ring')
  
  data_sort<-data1[order(data1$year),]
  
  gam_model1<-mgcv::gam(ring ~ s(vpd)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model2<-mgcv::gam(ring ~ s(vpd)+s(tmp)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model3<-mgcv::gam(ring ~ s(vpd)+s(pre)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  
  gam_model4<-mgcv::gam(ring ~ s(vpd)+s(swf)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" )
  #### multi
  gam_model1<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  gam_model2<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          ti(vpd,tmp)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  gam_model3<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          ti(vpd,pre)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  gam_model4<-mgcv::gam(ring ~s(tmp)+ s(pre)+s(swf)+s(vpd)+
                          ti(vpd,swf)+
                          s(year)+s(lat, bs="re")+s(lon, bs="re")+s(alt, bs="re"), data=data_sort,
                        na.action = "na.omit", method="REML" ) 
  
  sm1 <- summary(gam_model1)
  gam_terms1 <- data.frame(
    term    = rownames(sm1$s.table),
    EDF     = sm1$s.table[, "edf"],
    RefDF  = sm1$s.table[, "Ref.df"],
    F      = sm1$s.table[, "F"],
    p_value= sm1$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms1 <- gam_terms1[
    gam_terms1$term %in% c("s(vpd)","ti(vpd,tmp)"),
  ]
  
  model_terms1 <- data.frame(
    term    = vpd_terms1$term,
    EDF     = vpd_terms1$EDF,
    RefDF  = vpd_terms1$RefDF,
    F      = vpd_terms1$F,
    p_value= vpd_terms1$p_value,
    r2= sm1$r.sq
  )
  sm2 <- summary(gam_model2)
  gam_terms2 <- data.frame(
    term    = rownames(sm2$s.table),
    EDF     = sm2$s.table[, "edf"],
    RefDF  = sm2$s.table[, "Ref.df"],
    F      = sm2$s.table[, "F"],
    p_value= sm2$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms2 <- gam_terms2[
    gam_terms2$term %in% c("s(vpd)","ti(vpd,tmp)"),
  ]
  model_terms2 <- data.frame(
    term    = vpd_terms2$term,
    EDF     = vpd_terms2$EDF,
    RefDF  = vpd_terms2$RefDF,
    F      = vpd_terms2$F,
    p_value= vpd_terms2$p_value,
    r2= sm2$r.sq
  )
  sm3 <- summary(gam_model3)
  gam_terms3 <- data.frame(
    term    = rownames(sm3$s.table),
    EDF     = sm3$s.table[, "edf"],
    RefDF  = sm3$s.table[, "Ref.df"],
    F      = sm3$s.table[, "F"],
    p_value= sm3$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms3 <- gam_terms3[
    gam_terms3$term %in% c("s(vpd)","ti(vpd,pre)"),
  ]
  model_terms3 <- data.frame(
    term    = vpd_terms3$term,
    EDF     = vpd_terms3$EDF,
    RefDF  = vpd_terms3$RefDF,
    F      = vpd_terms3$F,
    p_value= vpd_terms3$p_value,
    r2= sm3$r.sq
  )
  sm4 <- summary(gam_model4)
  gam_terms4 <- data.frame(
    term    = rownames(sm4$s.table),
    EDF     = sm4$s.table[, "edf"],
    RefDF  = sm4$s.table[, "Ref.df"],
    F      = sm4$s.table[, "F"],
    p_value= sm4$s.table[, "p-value"],
    row.names = NULL
  )
  vpd_terms4 <- gam_terms4[
    gam_terms4$term %in% c("s(vpd)","ti(vpd,swf)"),
  ]
  model_terms4 <- data.frame(
    term    = vpd_terms4$term,
    EDF     = vpd_terms4$EDF,
    RefDF  = vpd_terms4$RefDF,
    F      = vpd_terms4$F,
    p_value= vpd_terms4$p_value,
    r2= sm4$r.sq
  )
}