# example
rm(list=ls())
library(mgcv) 
library(openxlsx)
library(visreg)
library(chngpt)
library(splines)
library(ggplot2)
library(rio)
library(jpeg)
library(export)
library(broom)
threshold <- data.frame()
bar_data <- matrix(NA, nrow=1000,ncol=75)


file_names <- list.files('bb')

name <- file_names[i]
graphics.off() 

data <- read.xlsx(paste0("bb/",name),sheet=1,na.strings="NaN",startRow=0,colNames = FALSE)
data1 <- data.frame(data)
colnames(data1) <- c('year','lat','lon','alt','tmp','pre','swf','vpd','ring')
data_sort<-data1[order(data1$year),]
#example 1
thresh_fit=chngptm(formula.1=ring~ns(tmp) + ns(pre) + ns(swf) +ns(lat) + ns(lon) + ns(alt)+ year, 
                   formula.2=~vpd, family="gaussian",
                   data=data_sort, type="segmented", lb.quantile = 0.5, ub.quantile=.95, var.type = "bootstrap")
threshold[i,1] <- thresh_fit$chngpt
boot_samps<-data.frame(thresh_fit$vcov$boot.samples)
bar_data[,i] <- boot_samps$chngpt

logliks_data1<-data.frame(thresh_fit$logliks)
threshold_data1<-data.frame(thresh_fit$chngpts)
name1 <- substr(name,1,5)

write.csv(logliks_data1,paste0("F:/VPD_Threshold/Revise_PNAS/Results/logliks_data/",name1,'.csv'),row.names = FALSE)
write.csv(threshold_data1,paste0("F:/VPD_Threshold/Revise_PNAS/Results/threshold_data/",name1,'.csv'),row.names = FALSE)



